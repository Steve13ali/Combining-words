from telethon import TelegramClient

# اطلاعات API
api_id = 20874292  # API ID
api_hash = '825f83b3af9e314056500b9866d1720d'  # API Hash
phone_number = '+989380870253'  # شماره تلفن

client = TelegramClient('session_name', api_id, api_hash)

async def check_username(username):
    try:
        print(f"بررسی آیدی: {username}")  # پیام برای دیباگ
        result = await client.get_entity(username)
        print(f"آیدی {username} موجود است.")  # پیام برای دیباگ
        return True
    except Exception as e:
        print(f"خطا برای آیدی {username}: {e}")  # پیام خطا برای دیباگ
        return False

async def main():
    # خواندن ID ها از فایل
    try:
        with open('usernames.txt', 'r') as file:
            usernames = [line.strip() for line in file.readlines() if line.strip()]  # خواندن آیدی‌ها
    except FileNotFoundError:
        print("فایل 'usernames.txt' پیدا نشد.")
        return

    print(f"آیدی‌های خوانده شده: {usernames}")  # پیام برای دیباگ

    valid_usernames = []

    for username in usernames:
        if await check_username(username):
            valid_usernames.append(username)

    # ذخیره کردن و چاپ کردن ID های معتبر
    if valid_usernames:
        # ذخیره کردن در فایل
        with open("valid_usernames.txt", "w") as file:
            for valid_username in valid_usernames:
                file.write(valid_username + "\n")
        
        # چاپ کردن در کنسول
        print("آیدی‌های معتبر:")
        for valid_username in valid_usernames:
            print(valid_username)
        
        print("آیدی‌های معتبر در فایل 'valid_usernames.txt' ذخیره شدند.")
    else:
        print("هیچ آیدی معتبری یافت نشد.")

# اجرای برنامه
with client:
    client.loop.run_until_complete(main())