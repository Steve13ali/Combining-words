import itertools
import os
import sys

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

def generate_usernames(words, output_filename):
    usernames = set()
    word_count = len(words)

    print(f"Total number of entered words: {word_count}")
    print("Starting to combine words...")
    print()  # Add a line break

    # If only one word, notify the user
    if word_count == 1:
        print("You have entered only one word, and it has no combinations.")
        return usernames

    total_combinations = 0

    # Generate combinations from 1 to N words
    for i in range(1, word_count + 1):
        total_combinations += len(words) ** i

    for i in range(1, word_count + 1):
        for combo in itertools.product(words, repeat=i):
            # Filter out combinations that are just repetitions of the same word
            if len(set(combo)) == len(combo):  # Ensure unique words in the combo
                # Add direct combinations
                usernames.add(''.join(combo) + '@')

                # Add permutations of the combo
                for perm in itertools.permutations(combo):
                    usernames.add(''.join(perm) + '@')

            # Update progress
            progress = len(usernames)
            percent = (progress / total_combinations) * 100
            bar_length = 10  # Length of the progress bar
            bar_filled_length = int(bar_length * (percent / 100))

            # Clear console for fresh output
            clear_console()
            print(f"Total number of entered words: {word_count}")
            print("Starting to combine words...")
            print()  # Add a line break
            # Create the progress bar
            progress_bar = '█' * bar_filled_length + ' ' * (bar_length - bar_filled_length)
            sys.stdout.write(f"\rProgress: [{progress_bar}] {percent:.2f}%")
            sys.stdout.flush()

    # Final message when finished
    clear_console()
    print(f"Total number of entered words: {word_count}")
    print("Starting to combine words...")
    print("\rProgress: [██████████] finished")
    print(f"\nThe words have been combined and saved in the file {output_filename}")
    return usernames

def main():
    clear_console()  # Clear the console at the start

    # Remove existing usernames.txt if it exists
    if os.path.exists('usernames.txt'):
        os.remove('usernames.txt')

    while True:
        choice = input("How do you want to enter the words? \n[1 for file txt] \n[2 for manual input]: ")

        words = []

        if choice == '1':
            # Ask for file name with default as 'words'
            file_name = input("Enter the file name (default is 'words'): ") or 'words'
            if not file_name.endswith('.txt'):
                file_name += '.txt'
            # Read words from file
            try:
                with open(file_name, 'r', encoding='utf-8') as f:
                    words = [line.strip() for line in f.readlines() if line.strip()]  # Remove empty lines
                break  # Exit loop if file is successfully read
            except FileNotFoundError:
                print(f"File {file_name} not found. Please try again.")

        elif choice == '2':
            # Ask user for words
            input_words = input("Please enter the words separated by spaces: ")
            words = [word.strip() for word in input_words.split()]
            break  # Exit loop after manual input

        else:
            print("Invalid selection entered!")

    # Check if words list is empty
    if not words:
        print("No words entered!")
        return
    
    # Check if only one word is entered
    if len(words) == 1:
        print("You have entered only one word, and it has no combinations.")
        return

    # Ask for the output filename
    output_filename = input("Enter the output filename (default is 'usernames.txt'): ") or 'usernames.txt'
    
    usernames = generate_usernames(words, output_filename)
    
    # Save usernames to the specified file only if there are valid usernames
    if usernames:
        with open(output_filename, 'w', encoding='utf-8') as f:
            for username in usernames:
                f.write(username + '\n')

    print(f"\nTotal number of generated usernames: {len(usernames)}")

if __name__ == "__main__":
    main()